<?
$timezone = "Asia/Ho_Chi_Minh";
if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone);
include('lib.php');
$host='http://trangxoa.com/ungdung/rsdata/';
if(isset($_POST['submit_getlink'])){
	$txtlink=$_POST['txtlink'];
	$txtlink2arr=explode('|',$txtlink);
	header("Content-type: text/plain");
	header("Content-Disposition: attachment; filename=listlinks.txt");
	for($i=0;$i<(count($txtlink2arr)-1);$i++){
		echo $txtlink2arr[$i];
	}
}elseif(isset($_POST['submit'])){
	$str=$_POST['linktxt'];
	$str = base64_decode($str);
	header("Content-type: text/plain");
	header("Content-Disposition: attachment; filename=listlinks.txt");
	echo $str;
}
 ?>